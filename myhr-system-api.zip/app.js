const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  console.log(res);
});

app.use((req, res) => {
  res.send("logen");
});

app.listen(3000, (req, res, next) => {
  console.log("Listening : http://localhost:12345");
});
